# charlieplex_3x3: project revision record

This archive delivers the editable KiCad project `charlieplex_3x3`: `charlieplex_3x3.kicad_pro`, `charlieplex_3x3.kicad_sch` and `charlieplex_3x3.kicad_pcb` share one basename, so KiCad opens the root sheet and the board together. The files were renamed while packaging; the checked sources were not modified.

Working revision: none is encoded in the checked file names.

| File in this archive | Checked source |
| --- | --- |
| `charlieplex_3x3.kicad_pcb` | `charlieplex_3x3_routed.kicad_pcb` |
| `charlieplex_3x3.kicad_dru` | `charlieplex_3x3_routed.kicad_dru` |
| `charlieplex_3x3.kicad_pro` | `charlieplex_3x3_routed.kicad_pro` |
| `charlieplex_3x3.kicad_sch` | `charlieplex_3x3.kicad_sch` |
