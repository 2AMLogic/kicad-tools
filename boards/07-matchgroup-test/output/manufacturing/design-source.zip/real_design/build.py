#!/usr/bin/env python3
"""Rebuild the reviewed SDRAM routing and independently repeat its release gates.

Routing is a reviewed, hash-bound physical artifact. This command does not claim
that an unmeasured fresh autorouter run will reproduce the same placement or
length tuning. The logical circuit is regenerated independently on every build.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import shutil
from pathlib import Path

from kicad_tools.operations.pintype import annotate_pcb_file_pintypes
from kicad_tools.router.quantize import segment_angle_census

ROOT = Path(__file__).resolve().parent


def load_module(name: str):
    spec = importlib.util.spec_from_file_location(f"board07_release_{name}", ROOT / f"{name}.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def build(output: Path) -> dict:
    fixture = ROOT / "reviewed-routing"
    if (
        output.resolve() == ROOT
        or fixture == output.resolve()
        or fixture in output.resolve().parents
    ):
        raise ValueError("Output must not overwrite the reviewed design sources")
    manifest = json.loads((fixture / "manifest.json").read_text())
    authored = json.loads((ROOT / "authored-source/manifest.json").read_text())
    if manifest["authored_source_sha256"] != authored["sha256"]:
        raise ValueError("Reviewed routing belongs to a different authored physical source")
    for name, expected in manifest["sha256"].items():
        if hashlib.sha256((fixture / name).read_bytes()).hexdigest() != expected:
            raise ValueError(f"Reviewed routing hash mismatch: {name}")

    source_builder, validator = load_module("build_source"), load_module("validate")
    source_builder.build(output)
    candidate = output / "sdram_demo_routed.kicad_pcb"
    shutil.copy2(fixture / "sdram_demo.kicad_pcb", candidate)
    # Hash identity and electrical validation complement the fleet angle policy.
    # Check both shared escape source and routing before any release evidence.
    for pcb in (output / "sdram_demo.kicad_pcb", candidate):
        if segment_angle_census(pcb)[1]:
            raise RuntimeError(f"Reviewed source contains off-angle copper: {pcb}")
    # Issue #6025: the reviewed copper is hash-bound, so the fresh schematic's
    # pin names/types are carried onto the candidate's pads, as on the source.
    annotation = annotate_pcb_file_pintypes(candidate, output / "sdram_demo.kicad_sch")
    if annotation.missing_pads:
        raise ValueError(f"Pads without a schematic pin: {annotation.missing_pads}")
    # Issue #7213: the fixture's bare footprint names get their library IDs.
    source_builder.apply_library_ids(
        candidate, output / "sdram_demo.kicad_sch", authored.get("fiducials", {})
    )
    evidence = output / "validation"
    if not validator.check(candidate, output, evidence):
        raise RuntimeError(f"Reviewed routing failed fresh validation; inspect {evidence}")
    # Publish the exact board checked after native zone refill and rule emission.
    for suffix in (".kicad_pcb", ".kicad_pro", ".kicad_dru"):
        shutil.copy2(
            (evidence / "checked.kicad_pcb").with_suffix(suffix), candidate.with_suffix(suffix)
        )
    result = {
        "status": "validated routing",
        "parts": authored["parts"],
        "bound_pads": authored["bound_pads"],
        "pcb": candidate.name,
        "evidence": "validation/validation.json",
        "routing_method": "reviewed artifact; independently regenerated circuit and fresh gates",
        "hardware_tested": False,
        "routed": True,
        "manufacturing_complete": False,
        "manufacturing_export_required": True,
    }
    (output / "build.json").write_text(json.dumps(result, indent=2) + "\n")
    (output / "status.json").write_text(json.dumps(result, indent=2) + "\n")
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    print(json.dumps(build(parser.parse_args().output), indent=2))
