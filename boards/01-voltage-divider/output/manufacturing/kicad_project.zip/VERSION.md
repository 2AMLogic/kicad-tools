# voltage_divider: project revision record

This archive delivers the editable KiCad project `voltage_divider`: `voltage_divider.kicad_pro`, `voltage_divider.kicad_sch` and `voltage_divider.kicad_pcb` share one basename, so KiCad opens the root sheet and the board together. The files were renamed while packaging; the checked sources were not modified.

Working revision: none is encoded in the checked file names.

| File in this archive | Checked source |
| --- | --- |
| `voltage_divider.kicad_pcb` | `voltage_divider_routed.kicad_pcb` |
| `voltage_divider.kicad_dru` | `voltage_divider_routed.kicad_dru` |
| `voltage_divider.kicad_pro` | `voltage_divider_routed.kicad_pro` |
| `voltage_divider.kicad_sch` | `voltage_divider.kicad_sch` |
