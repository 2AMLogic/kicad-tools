# bldc_controller: project revision record

This archive delivers the editable KiCad project `bldc_controller`: `bldc_controller.kicad_pro`, `bldc_controller.kicad_sch` and `bldc_controller.kicad_pcb` share one basename, so KiCad opens the root sheet and the board together. The files were renamed while packaging; the checked sources were not modified.

Working revision: none is encoded in the checked file names.

| File in this archive | Checked source |
| --- | --- |
| `bldc_controller.kicad_pcb` | `bldc_controller_routed.kicad_pcb` |
| `bldc_controller.kicad_dru` | `bldc_controller_routed.kicad_dru` |
| `bldc_controller.kicad_pro` | `bldc_controller_routed.kicad_pro` |
| `bldc_controller.kicad_sch` | `bldc_controller.kicad_sch` |
