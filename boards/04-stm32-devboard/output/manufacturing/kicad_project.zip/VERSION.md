# stm32_devboard: project revision record

This archive delivers the editable KiCad project `stm32_devboard`: `stm32_devboard.kicad_pro`, `stm32_devboard.kicad_sch` and `stm32_devboard.kicad_pcb` share one basename, so KiCad opens the root sheet and the board together. The files were renamed while packaging; the checked sources were not modified.

Working revision: none is encoded in the checked file names.

| File in this archive | Checked source |
| --- | --- |
| `stm32_devboard.kicad_pcb` | `stm32_devboard_routed.kicad_pcb` |
| `stm32_devboard.kicad_dru` | `stm32_devboard_routed.kicad_dru` |
| `stm32_devboard.kicad_pro` | `stm32_devboard_routed.kicad_pro` |
| `stm32_devboard.kicad_sch` | `stm32_devboard.kicad_sch` |
