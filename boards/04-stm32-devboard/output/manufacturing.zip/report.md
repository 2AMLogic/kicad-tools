---
title: "stm32_devboard_routed"
subtitle: "Design Report"
author: "kicad-tools 0.29.0"
date: "Rev A | 2026-11-28 | jlcpcb-tier1"
geometry: "margin=1in"
fontsize: 11pt
colorlinks: true
header-includes:
  - \usepackage{longtable}
  - \usepackage{booktabs}
  - \usepackage{array}
  - \usepackage{float}
---

## Board Summary

| Property | Value |
|----------|-------|
| Layers | 2 copper (F.Cu, B.Cu) |
| Footprints | 20 (18 SMD, 2 THT, 0 other) |
| Nets | 12 |
| Traces | 94 segments |
| Vias | 32 |
| Board Size | 60.0 x 40.0 mm |

## Design Overview

### Theory of Operation

STM32F103C8 Development Board

End-to-end design example

Demonstrates circuit blocks API

### Power Architecture

**Power Rails**: +3.3V, +5V, GND

| Regulator | Device |
|-----------|--------|
| U1 | MCP1825S-3302E/DB |

## Assembly Notes

1 fine-pitch component; 1 polarized component

- **Fine-pitch components**: 1 (U2)
- **Polarized components**: 1 -- check orientation markings

## ERC Status

| Metric | Count |
|--------|-------|
| Errors | 0 |
| Warnings | 0 |

**Status**: PASS

\newpage

## Schematic Overview

### Schematic: stm32_devboard

![Schematic: stm32_devboard](images/schematic_stm32_devboard.png)


\newpage

## PCB Layout

![PCB Front](images/pcb_front.png)

![PCB Back](images/pcb_back.png)

### Copper

![PCB Copper](images/pcb_copper.png)

### Assembly

![Assembly](images/assembly.png)


\newpage

## Copper Layers

### F.Cu

![F.Cu](images/layer_F_Cu.png)

### B.Cu

![B.Cu](images/layer_B_Cu.png)


\newpage

## Bill of Materials

| Value | Package | Qty | References | MPN | LCSC |
|-------|---------|-----|------------|-----|------|
| 100nF | C_0805_2012Metric | 5 | C3, C12, C13, C14, C15 |  |  |
| 10uF | C_0805_2012Metric | 2 | C1, C2 |  |  |
| 20pF | C_0805_2012Metric | 2 | C10, C11 |  |  |
| 4.7uF | C_0805_2012Metric | 1 | C16 |  |  |
| LED | LED_0805_2012Metric | 1 | D1 |  |  |
| SWD-6 | PinHeader_1x06_P2.54mm_Vertical | 1 | J1 |  |  |
| 10k | R_0805_2012Metric | 1 | R2 |  |  |
| 330R | R_0805_2012Metric | 1 | R1 |  |  |
| MCP1825S-3302E/DB | SOT-223-3_TabPin2 | 1 | U1 | MCP1825S-3302E/DB | C148031 |
| STM32F103C8T6 | LQFP-48_7x7mm_P0.5mm | 1 | U2 |  |  |
| 8MHz | Crystal_HC49-4H_Vertical | 1 | Y1 |  |  |


\newpage

## DRC Status (`--mfr jlcpcb-tier1` profile with reviewed fabrication process: via drill 0.15 mm, via diameter 0.3 mm, annular ring 0.075 mm)

| Metric | Count |
|--------|-------|
| Errors | 0 |
| Errors: kct (reviewed process rules, not stock `--mfr jlcpcb-tier1`) | 0 |
| Errors: kicad-cli (geometric) | 0 |
| Warnings | 4 |
| Blocking | 0 |

**Status**: PASS

### Violations by Type

| Violation Type | Count |
|----------------|-------|
| pour_slot | 4 |



\newpage

## Manufacturing Readiness

**Verdict**: WARNING

### Action Items

- **[OPTIONAL]** Refill zones to verify 3 zone-connected nets, then re-run kct audit
- **[OPTIONAL]** Review 4 DRC warnings


\newpage

## Routing Status

| Metric | Value |
|--------|-------|
| Signal Net Completion | 100.0% (9/9) |
| Overall Completion | 100.0% |
| Complete Nets | 12 / 12 |
| Zone-Connected Nets | 3 |
| Incomplete Nets | 0 |
| Unconnected Pads | 0 |

### Zone-Connected Nets

- +3.3V
- +5V
- GND


## Cost Estimate

| Metric | Per Board (estimated) |
|--------|-------|
| PCB Fabrication | ~0.88 USD |
| Components (estimated) | ~1.4 USD |
| Assembly (estimated) | ~2.04 USD |
| **Total (estimated)** | **~4.31 USD** |
| Batch Quantity | 5 |
| Batch Total (estimated) | ~21.55 USD |

