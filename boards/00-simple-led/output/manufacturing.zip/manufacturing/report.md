---
title: "simple_led_routed"
subtitle: "Design Report"
author: "kicad-tools 0.29.0"
date: "Rev A | 2026-11-27 | jlcpcb"
geometry: "margin=1in"
fontsize: 11pt
colorlinks: true
header-includes:
  - \usepackage{longtable}
  - \usepackage{booktabs}
  - \usepackage{array}
  - \usepackage{float}
---

## Board Summary

| Property | Value |
|----------|-------|
| Layers | 2 copper (F.Cu, B.Cu) |
| Footprints | 6 (4 SMD, 2 THT, 0 other) |
| Nets | 3 |
| Traces | 2 segments |
| Vias | 0 |
| Board Size | 25.0 x 20.0 mm |

## Design Overview

### Theory of Operation

Simple LED - Hello World

Minimal LED circuit

5V input, 330 ohm resistor, LED

### Power Architecture

**Power Rails**: GND, VCC

## Assembly Notes

1 polarized component

- **Polarized components**: 1 -- check orientation markings

## ERC Status

| Metric | Count |
|--------|-------|
| Errors | 0 |
| Warnings | 0 |

**Status**: PASS

\newpage

## Schematic Overview

### Schematic: simple_led

![Schematic: simple_led](images/schematic_simple_led.png)


\newpage

## PCB Layout

![PCB Front](images/pcb_front.png)

![PCB Back](images/pcb_back.png)

### Copper

![PCB Copper](images/pcb_copper.png)

### Assembly

![Assembly](images/assembly.png)


\newpage

## Copper Layers

### F.Cu

![F.Cu](images/layer_F_Cu.png)

### B.Cu

![B.Cu](images/layer_B_Cu.png)


\newpage

## Bill of Materials

| Value | Package | Qty | References |
|-------|---------|-----|------------|
| LED | LED_D5.0mm | 1 | D1 |
| PWR | PinHeader_1x02_P2.54mm_Vertical | 1 | J1 |
| 330 | R_0805_2012Metric | 1 | R1 |


\newpage

## DRC Status (`--mfr jlcpcb` rules)

| Metric | Count |
|--------|-------|
| Errors | 0 |
| Errors: kct (`--mfr jlcpcb` rules) | 0 |
| Errors: kicad-cli (geometric) | 0 |
| Warnings | 0 |
| Blocking | 0 |

**Status**: PASS




\newpage

## Manufacturing Readiness

**Verdict**: READY

### Action Items

- **[OPTIONAL]** Refill zones to verify 2 zone-connected nets, then re-run kct audit


\newpage

## Routing Status

| Metric | Value |
|--------|-------|
| Signal Net Completion | 100.0% (1/1) |
| Overall Completion | 100.0% |
| Complete Nets | 3 / 3 |
| Zone-Connected Nets | 2 |
| Incomplete Nets | 0 |
| Unconnected Pads | 0 |

### Zone-Connected Nets

- GND
- VCC


## Cost Estimate

| Metric | Per Board (estimated) |
|--------|-------|
| PCB Fabrication | ~0.5 USD |
| Components (estimated) | ~0.15 USD |
| Assembly (estimated) | ~1.94 USD |
| **Total (estimated)** | **~2.6 USD** |
| Batch Quantity | 5 |
| Batch Total (estimated) | ~12.98 USD |

