# simple_led: project revision record

This archive delivers the editable KiCad project `simple_led`: `simple_led.kicad_pro`, `simple_led.kicad_sch` and `simple_led.kicad_pcb` share one basename, so KiCad opens the root sheet and the board together. The files were renamed while packaging; the checked sources were not modified.

Working revision: none is encoded in the checked file names.

| File in this archive | Checked source |
| --- | --- |
| `simple_led.kicad_pcb` | `simple_led_routed.kicad_pcb` |
| `simple_led.kicad_dru` | `simple_led_routed.kicad_dru` |
| `simple_led.kicad_pro` | `simple_led_routed.kicad_pro` |
| `simple_led.kicad_sch` | `simple_led.kicad_sch` |
